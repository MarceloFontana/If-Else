
rootProject.name = "Triangulo"

