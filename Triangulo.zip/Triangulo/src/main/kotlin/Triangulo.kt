class Triangulo {

}