fun main(args: Array<String>) {
    println("Digite o primeio lado do triângulo:")
    val lad1 = readLine()!!.toFloat()
    println("Digite o segundo lado do triangulo")
    val lad2 = readLine()!!.toFloat()
    println("Digite o terceiro lado do triangulo")
    val lad3 = readLine()!!.toFloat()
    if(
        (lad1 < lad2 + lad3)||(lad2 < lad3 + lad1)|| (lad3 < lad1 + lad2)
    ){
        print("Os lados informados formam um ")
    }
      if (
        (lad1 == lad2 && lad2 == lad3 )
    ){
        print("Trinângulo  EQUILATERO")
    }else if(
        (lad1 != lad2 && lad2 != lad3)
    ){
        print("Triângulo ESCALENO")
    }else if(
        (lad1 == lad2 && lad2 != lad3)||(lad2 == lad3 && lad3 != lad1)||(lad3 == lad1 && lad1 != lad2)
    ){
        print("Triângulo ISÓSCELES")
    }else{
        print("Os lados não formam um triangulo")
    }

}