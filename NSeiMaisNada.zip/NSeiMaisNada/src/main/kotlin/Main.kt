fun main() {
    println("Mora perto da vitima?Digite ${"S"} para sim e ${"N"} para nao")
    val res1 = readLine()!!.toString()
    println("Esteve no local do crime? Digite ${"S"} para sim e ${"N"} para nao")
    val res2 = readLine()!!.toString()
    println("Telefonou para a vitima? Digite ${"S"} para sim e ${"N"} para nao")
    val res3 = readLine()!!.toString()
    println("Devia para vitima? Digite ${"S"} para sim e ${"N"} para nao")
    val res4 = readLine()!!.toString()
    println("Trabalhou com a vitima?Digite ${"S"} para sim e ${"N"} para nao")
    val res5 = readLine()!!.toString()

    val somaRespostas = res1 + res2 + res3 + res4 + res5

    if(
        (somaRespostas < 2)
    ){
        print("Inocente")
    }
    else if(
        (somaRespostas == 2)
    ){
        print("Inocente")
    }
    else if(
        (somaRespostas >=3) && (somaRespostas <= 4)
    ){
        print("Cumplice")
    }
    else(
        ()
    )

}

