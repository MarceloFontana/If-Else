
fun main(args: Array<String>) {
    println("Informe o ano para descobrir se ele é bissexto ou informe 0 para saber o ano atual:")
    val ano = readLine()!!.toInt()


    if(
        (ano % 4 == 0)
    ){
        print("O ano $ano é BISSEXTO")
    }else if(
        (ano % 4 == 0)&&(ano % 100 != 0)
    ){
        print("O ano $ano é BISSEXTO")
    }else if(
        (ano % 4 == 0)&&(ano % 100 != 0)&&(ano % 400 == 0)
    ){
        print("O ano $ano é BISSEXTO")
    }else{
        (ano %4 !=0)&&(ano %100 == 0)&& (ano %400 !=0)
        print("O ano $ano não é BISSEXTO")
    }
}