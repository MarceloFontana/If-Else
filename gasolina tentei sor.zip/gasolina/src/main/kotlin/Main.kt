fun main(args: Array<String>) {
    println("Digite quantos litros você deseja abastecer:")
    val litr = readLine()!!.toFloat()
    println("Digite A para álcool ou G para gasolina:")
    val ag = readLine()!!.toString()
    val preco:Int = 0

    if(
        (ag == "A")||(ag == "a")
    ){
        (preco == litr * 1.9)
    }
    else if (
        (litr <=20)
    ){
        (preco -= 1.9* litr* 3/100)
    }
    else if(
        (preco -= 1.9 * litr * 5/100)
    ) {
    }
    else if(
        (ag == "G")||(ag == "g")
    ){
        (preco == litr * 2.5)
    }
    else if(
        (litr <= 20)
    ){
        (preco -= 2.5 * litr * 4/100)

    }else(
        (preco -= 2.5 * litr * 6/100)
    )
        print("O preço a pagar é R$ ${preco:*2} )
    }
}